from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='jetbot_pro_ros2',
            executable='camera',  # <--- aquí va el nombre del ejecutable
            name='camera'
        )
    ])
