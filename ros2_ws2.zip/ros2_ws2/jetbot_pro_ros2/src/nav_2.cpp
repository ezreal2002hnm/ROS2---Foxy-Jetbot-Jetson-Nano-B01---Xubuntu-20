#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <algorithm>

class NavigationNode : public rclcpp::Node
{
public:
    NavigationNode() : Node("navigation_node")
    {
        linear_speed_ = 0.3;
        angular_speed_ = 0.75;
        obstacle_distance_ = 0.5;

        cmd_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
        scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10,
            std::bind(&NavigationNode::scan_callback, this, std::placeholders::_1)
        );

        RCLCPP_INFO(this->get_logger(), "Navigation node started!");
    }

private:
    void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        // Distancia mínima frontal
        auto start = msg->ranges.begin() + msg->ranges.size()/3;
        auto end = msg->ranges.begin() + 2*msg->ranges.size()/3;
        float front_min = std::min(*std::min_element(start, end), static_cast<float>(obstacle_distance_));

        geometry_msgs::msg::Twist cmd;
        if (front_min < obstacle_distance_) {
            cmd.linear.x = 0.0;
            cmd.angular.z = angular_speed_;
        } else {
            cmd.linear.x = linear_speed_;
            cmd.angular.z = 0.0;
        }

        cmd_pub_->publish(cmd);
    }

    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
    double linear_speed_, angular_speed_, obstacle_distance_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<NavigationNode>());
    rclcpp::shutdown();
    return 0;
}
