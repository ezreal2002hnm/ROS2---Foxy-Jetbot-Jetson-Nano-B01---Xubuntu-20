from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='jetbot_pro_ros2',
            executable='nav_2',  # nombre del ejecutable C++ que compilemos con colcon
            name='navigation_node',
            output='screen'
        ),
    ])
