#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from sensor_msgs.msg import LaserScan  # Para leer los mensajes del LIDAR

class LaserTFBroadcaster(Node):
    def __init__(self):
        super().__init__('laser_tf_broadcaster')
        self.tf_broadcaster = TransformBroadcaster(self)

        # Suscripción al LIDAR para sincronizar los timestamps
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',  # Cambia si tu topic del LIDAR es otro
            self.broadcast_tf_from_scan,
            10  # QoS
        )

    def broadcast_tf_from_scan(self, msg):
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()  # Sincronizamos con el LIDAR
        t.header.frame_id = 'base_link'
        t.child_frame_id = 'laser_frame'

        # Posición del láser respecto a base_link
        t.transform.translation.x = 0.0
        t.transform.translation.y = 0.0
        t.transform.translation.z = 0.15

        # Rotación (quaternion) del láser
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = 0.0
        t.transform.rotation.w = 1.0

        self.tf_broadcaster.sendTransform(t)

def main():
    rclpy.init()
    node = LaserTFBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
