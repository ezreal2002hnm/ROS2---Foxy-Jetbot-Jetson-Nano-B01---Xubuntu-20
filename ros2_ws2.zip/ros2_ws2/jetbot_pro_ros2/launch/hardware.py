from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # JetBot motor controller
        Node(
            package='jetbot_pro_ros2',
            executable='jetbot',
            name='jetbot',
            output='screen'
        ),

        # Cámara
        Node(
            package='gscam',
            executable='gscam_node',
            name='camera',
            output='screen',
            parameters=[{
                'camera_name': 'jetbot_cam',
                'camera_info_url': '',
                'gscam_config': 'v4l2src device=/dev/video0 ! video/x-raw, width=224, height=224, framerate=30/1 ! videoconvert ! video/x-raw, format=BGR ! appsink'
            }]
        ),

        # LiDAR si tienes RPLIDAR
        Node(
            package='rplidar_ros',
            executable='rplidarNode',
            name='rplidar',
            output='screen',
            parameters=[{
                'serial_port': '/dev/ttyTHS*',
                'frame_id': 'laser'
            }]
        )
    ])
