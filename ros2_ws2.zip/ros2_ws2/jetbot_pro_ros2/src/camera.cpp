#include <opencv2/opencv.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <cv_bridge/cv_bridge.h>

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("camera");
    auto pub = node->create_publisher<sensor_msgs::msg::Image>("camera/image_raw", 10);

    std::string pipeline = 
        "nvarguscamerasrc sensor-id=0 ! "
        "video/x-raw(memory:NVMM), width=640, height=480, format=NV12, framerate=20/1 ! "
        "nvvidconv ! video/x-raw, format=BGRx ! "
        "videoconvert ! video/x-raw, format=BGR ! appsink";

    cv::VideoCapture cap(pipeline, cv::CAP_GSTREAMER);

    if (!cap.isOpened()) {
        RCLCPP_ERROR(node->get_logger(), "No se pudo abrir la cámara");
        return -1;
    }

    cv::Mat frame;
    sensor_msgs::msg::Image::SharedPtr msg;
    rclcpp::Rate loop_rate(20);

    while (rclcpp::ok()) {
        cap >> frame;
        if (frame.empty()) continue;

        msg = cv_bridge::CvImage(std_msgs::msg::Header(), "bgr8", frame).toImageMsg();
        pub->publish(*msg);

        rclcpp::spin_some(node);
        loop_rate.sleep();
    }

    cap.release();
    rclcpp::shutdown();
    return 0;
}
